import PaymentVerificationForm from "@/components/payment-verification-form"

export default async function VerifyPaymentPage() {
  return <PaymentVerificationForm />
}
