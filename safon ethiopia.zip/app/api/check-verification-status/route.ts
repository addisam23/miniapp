import { NextResponse } from "next/server"
import type { NextRequest } from "next/server"

export const dynamic = "force-dynamic"
export const runtime = "nodejs"

export async function GET(request: NextRequest) {
  try {
    const { getUserPaymentProof } = await import("@/lib/database")

    const { searchParams } = new URL(request.url)
    const userId = searchParams.get("userId")

    if (!userId) {
      return NextResponse.json({ error: "User ID required" }, { status: 400 })
    }

    const paymentProof = await getUserPaymentProof(userId)

    if (!paymentProof) {
      return NextResponse.json({ error: "Payment proof not found" }, { status: 404 })
    }

    return NextResponse.json({
      status: paymentProof.status,
      adminNote: paymentProof.adminNote,
    })
  } catch (error) {
    console.error("Check status error:", error)
    return NextResponse.json({ error: "Internal server error" }, { status: 500 })
  }
}
