import { NextResponse } from "next/server"
import type { NextRequest } from "next/server"
import { writeFile, mkdir } from "fs/promises"
import { join } from "path"
import { existsSync } from "fs"

export const dynamic = "force-dynamic"
export const runtime = "nodejs"

export async function POST(request: NextRequest) {
  try {
    // Dynamic imports to avoid build-time issues
    const { getServerSession } = await import("next-auth")
    const { authOptions } = await import("@/lib/auth")
    const { createPaymentProof } = await import("@/lib/database")

    const session = await getServerSession(authOptions)

    if (!session) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
    }

    const formData = await request.formData()
    const file = formData.get("file") as File

    if (!file) {
      return NextResponse.json({ error: "No file provided" }, { status: 400 })
    }

    // Validate file type
    if (!file.type.startsWith("image/")) {
      return NextResponse.json({ error: "Invalid file type. Please upload an image." }, { status: 400 })
    }

    // Validate file size (5MB limit)
    if (file.size > 5 * 1024 * 1024) {
      return NextResponse.json({ error: "File too large. Maximum size is 5MB." }, { status: 400 })
    }

    // Create unique filename
    const timestamp = Date.now()
    const extension = file.name.split(".").pop() || "jpg"
    const filename = `payment-proof-${session.user.id}-${timestamp}.${extension}`

    // Ensure upload directory exists
    const uploadDir = join(process.cwd(), "public", "uploads")
    if (!existsSync(uploadDir)) {
      await mkdir(uploadDir, { recursive: true })
    }

    // Save file
    const bytes = await file.arrayBuffer()
    const buffer = Buffer.from(bytes)
    const filePath = join(uploadDir, filename)

    await writeFile(filePath, buffer)

    // Save to database
    const imageUrl = `/uploads/${filename}`
    const paymentProof = await createPaymentProof({
      userId: session.user.id,
      imageUrl,
      status: "pending",
    })

    return NextResponse.json({ success: true, id: paymentProof?.id })
  } catch (error) {
    console.error("Upload error:", error)
    return NextResponse.json(
      {
        error: "Failed to upload file. Please try again.",
      },
      { status: 500 },
    )
  }
}
