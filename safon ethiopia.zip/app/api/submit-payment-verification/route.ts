import { NextResponse } from "next/server"
import type { NextRequest } from "next/server"
import { writeFile, mkdir } from "fs/promises"
import { join } from "path"
import { existsSync } from "fs"
import bcrypt from "bcryptjs"

export const dynamic = "force-dynamic"
export const runtime = "nodejs"

export async function POST(request: NextRequest) {
  try {
    const { createUserWithPaymentProof } = await import("@/lib/database")

    const formData = await request.formData()
    const file = formData.get("file") as File
    const name = formData.get("name") as string
    const email = formData.get("email") as string
    const phone = formData.get("phone") as string
    const telegramUsername = formData.get("telegramUsername") as string

    if (!file || !name || !email || !phone) {
      return NextResponse.json({ error: "Missing required fields" }, { status: 400 })
    }

    // Validate email format
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/
    if (!emailRegex.test(email)) {
      return NextResponse.json({ error: "Invalid email format" }, { status: 400 })
    }

    // Validate file type
    if (!file.type.startsWith("image/")) {
      return NextResponse.json({ error: "Invalid file type. Please upload an image." }, { status: 400 })
    }

    // Validate file size (5MB limit)
    if (file.size > 5 * 1024 * 1024) {
      return NextResponse.json({ error: "File too large. Maximum size is 5MB." }, { status: 400 })
    }

    // Create unique filename
    const timestamp = Date.now()
    const extension = file.name.split(".").pop() || "jpg"
    const filename = `payment-proof-${timestamp}.${extension}`

    // Ensure upload directory exists
    const uploadDir = join(process.cwd(), "public", "uploads")
    if (!existsSync(uploadDir)) {
      await mkdir(uploadDir, { recursive: true })
    }

    // Save file
    const bytes = await file.arrayBuffer()
    const buffer = Buffer.from(bytes)
    const filePath = join(uploadDir, filename)

    await writeFile(filePath, buffer)

    // Create user and payment proof
    const imageUrl = `/uploads/${filename}`

    // Generate a temporary password (user won't need to login)
    const tempPassword = await bcrypt.hash(Math.random().toString(36), 12)

    const result = await createUserWithPaymentProof({
      name,
      email,
      phone,
      telegramUsername: telegramUsername || null,
      password: tempPassword,
      imageUrl,
    })

    if (!result) {
      return NextResponse.json({ error: "Failed to create user" }, { status: 500 })
    }

    return NextResponse.json({
      success: true,
      userId: result.userId,
      message: "Payment verification submitted successfully",
    })
  } catch (error) {
    console.error("Submit verification error:", error)

    // Handle specific errors
    if (error instanceof Error && error.message.includes("already exists")) {
      return NextResponse.json({ error: "User with this email already exists" }, { status: 400 })
    }

    return NextResponse.json(
      {
        error: "Failed to submit verification. Please try again.",
      },
      { status: 500 },
    )
  }
}
