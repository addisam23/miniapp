import { NextResponse } from "next/server"
import type { NextRequest } from "next/server"

export const dynamic = "force-dynamic"
export const runtime = "nodejs"

export async function POST(request: NextRequest) {
  try {
    const { createWithdrawRequest } = await import("@/lib/database")

    const body = await request.json()
    const { userId, method, amount, accountInfo } = body

    if (!userId || !method || !amount || !accountInfo) {
      return NextResponse.json({ error: "Missing required fields" }, { status: 400 })
    }

    if (typeof amount !== "number" || amount <= 0) {
      return NextResponse.json({ error: "Invalid amount" }, { status: 400 })
    }

    const withdrawRequest = await createWithdrawRequest({
      userId,
      method,
      amount,
      accountInfo,
      status: "pending",
    })

    return NextResponse.json({ success: true, id: withdrawRequest?.id })
  } catch (error) {
    console.error("Withdraw error:", error)
    return NextResponse.json({ error: "Internal server error" }, { status: 500 })
  }
}
