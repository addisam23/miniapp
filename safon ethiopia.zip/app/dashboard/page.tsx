import { redirect } from "next/navigation"
import { getUserByIdWithStats, getUserPaymentProof } from "@/lib/database"
import UserDashboard from "@/components/user-dashboard"

interface DashboardPageProps {
  searchParams: {
    userId?: string
  }
}

export default async function DashboardPage({ searchParams }: DashboardPageProps) {
  const { userId } = searchParams

  if (!userId) {
    redirect("/verify-payment")
  }

  try {
    // Get user data and payment proof
    const [user, paymentProof] = await Promise.allSettled([getUserByIdWithStats(userId), getUserPaymentProof(userId)])

    const userData = user.status === "fulfilled" ? user.value : null
    const proofData = paymentProof.status === "fulfilled" ? paymentProof.value : null

    if (!userData) {
      redirect("/verify-payment")
    }

    // Check if user has verified payment
    if (!proofData || proofData.status !== "approved") {
      redirect("/verify-payment")
    }

    return <UserDashboard user={userData} />
  } catch (error) {
    console.error("Dashboard error:", error)
    redirect("/verify-payment")
  }
}
